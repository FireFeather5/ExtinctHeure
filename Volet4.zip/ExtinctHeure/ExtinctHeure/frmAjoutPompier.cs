﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pinpon;

namespace ExtinctHeure
{
    public partial class frmAjoutPompier : Form
    {
        private SQLiteConnection cx;
        public frmAjoutPompier()
        {
            InitializeComponent();
            try
            {
                this.cx = Connexion.Connec;
            }
            catch (SQLiteException ex)
            {
                MessageBox.Show("Erreur de l'accès à la DB : " + ex.Message);
            }
        }

        private void frmAjoutPompier_Load(object sender, EventArgs e)
        {
            ChargercboCasernes();
            ChargerCboGrades();
            ChargerLstHabilitations();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            DialogResult= DialogResult.Cancel;
        }

        private void txtNom_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
            if (char.IsLetter(e.KeyChar) || char.IsControl(e.KeyChar)) { e.Handled = false; }
        }

        private void txtTelephone_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
            if ((char.IsDigit(e.KeyChar) && txtTelephone.TextLength < 10) || char.IsControl(e.KeyChar)) { e.Handled = false; }
        }

        private void ChargercboCasernes()
        {
            string req = "SELECT nom FROM Caserne";
            SQLiteCommand cmd = new SQLiteCommand(req, this.cx);
            SQLiteDataReader caserneReader = cmd.ExecuteReader();

            while (caserneReader.Read())
            {
                string nomCaserne = caserneReader.GetString(0);
                this.cboCasernes.Items.Add(nomCaserne);
            }
        }

        private void ChargerCboGrades()
        {
            string req = "SELECT libelle FROM Grade";
            SQLiteCommand cmd = new SQLiteCommand(req, this.cx);
            SQLiteDataReader gradesReader = cmd.ExecuteReader();

            while (gradesReader.Read())
            {
                string nomgrades = gradesReader.GetString(0);
                this.cboGrades.Items.Add(nomgrades);
            }
        }

        private void ChargerLstHabilitations()
        {
            string req = "SELECT libelle FROM Habilitation";
            SQLiteCommand cmd = new SQLiteCommand(req, this.cx);
            SQLiteDataReader habilitationReader = cmd.ExecuteReader();

            while (habilitationReader.Read())
            {
                string nomHabilitation = habilitationReader.GetString(0);
                this.chklstHabilitations.Items.Add(nomHabilitation);
            }
        }
    }
}
